import re

VIDEO_PREFIX = '/video/arabicchannels'

NAME = 'Arabic TV Channels'
ART  = 'art-default.jpg'
ICON = 'icon-default.png'
ALJAZEERA = 'icon-aljazeera.png'
ALARABIYA = 'icon-alarabiya.png'
BBC = 'icon-bbc.png'
IQRAA = 'icon-iqraa.png'

####################################################################################################

def Start():
  Plugin.AddPrefixHandler(VIDEO_PREFIX, VideoMainMenu, NAME, ICON, ART)

  Plugin.AddViewGroup("InfoList", viewMode="InfoList", mediaType="items")
  Plugin.AddViewGroup("List", viewMode="List", mediaType="items")


  MediaContainer.title1 = NAME
  MediaContainer.viewGroup = "List"
  MediaContainer.art = R(ART)
  RTMPVideoItem.thumb = R(ICON)
  DirectoryItem.thumb = R(ICON)
  VideoItem.thumb = R(ICON)

  HTTP.CacheTime = CACHE_1HOUR
  HTTP.Headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en-US; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13'

####################################################################################################

def VideoMainMenu():
  dir = MediaContainer(viewGroup="MediaPreview")

  dir.Append(RTMPVideoItem('rtmp://aljazeeraflashlivefs.fplive.net/aljazeeraflashlive-live', clip='aljazeera_ara_high', live=True, title="Al-Jazeera", thumb = R(ALJAZEERA)))

  dir.Append(RTMPVideoItem('rtmp://llnwvps45.fc.llnwd.net/llnwvps45/_definst_', clip='7HOgy0XwSwcgkZ7HZf-_bg_C_JRd_imTFos6E2QyQF-ls_720_576_128_1', live=True, title = "Al-Arabiya", thumb = R(ALARABIYA)))

  dir.Append(RTMPVideoItem('rtmp://63.233.126.93:1935/live?_fcs_vhost=wsliveflash.bbc.co.uk&undefined', clip='atv_live@3584', live=True, title="BBC Arabic", thumb = R(BBC)))

  dir.Append(RTMPVideoItem('rtmp://fl1.viastreaming.net/iqraatv', clip='livestream', live=True, title="Iqraa TV", thumb = R(IQRAA)))

  return dir

####################################################################################################
